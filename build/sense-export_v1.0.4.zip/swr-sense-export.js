/*!

* sense-export - Just a simple button to export data in your Qlik Sense application without displaying them in a table first.
*
* @version v1.0.4
* @link 
* @author [object Object]
* @license MIT
*/


/* global define */
define(["jquery","qlik","./properties","./initialproperties","text!./lib/css/main.min.css","text!./template.ng.html","./lib/external/sense-extension-utils/general-utils","./lib/components/eui-button/eui-button","./lib/components/eui-overlay/eui-overlay","./lib/components/eui-simple-table/eui-simple-table"],function($,qlik,props,initProps,cssContent,ngTemplate,generalUtils){"use strict";generalUtils.addStyleToHeader(cssContent);return generalUtils.addStyleLinkToHeader("/extensions/swr-sense-export/lib/external/fontawesome/css/font-awesome.min.css","swr_sense_export__fontawesome"),{definition:props,initialProperties:initProps,snapshot:{canTakeSnapshot:!1},template:ngTemplate,controller:["$scope",function($scope){$scope.$watchCollection("layout.props",function(newVals,oldVals){Object.keys(newVals).forEach(function(key){newVals[key]!==oldVals[key]&&($scope[key]=newVals[key])})}),$scope.showUnsupportedOverlay=function(){return void 0===qlik.table},$scope.debug=function(){return!0===$scope.layout.props.isDebug&&qlik.navigation&&"edit"===qlik.navigation.getMode()},$scope.export=function(){var exportOpts={format:$scope.layout.props.exportFormat,state:$scope.layout.props.exportState,filename:$scope.layout.props.exportFileName,download:!0};if(qlik.table){qlik.table(this).exportData(exportOpts,function(result){})}}}]}});